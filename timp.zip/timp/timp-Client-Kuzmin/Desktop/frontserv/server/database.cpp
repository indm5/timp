#include "database.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QCryptographicHash>
#include <QDebug>
#include <QDir>

bool Database::initialize()
{
    QDir().mkpath(".");

    m_db = QSqlDatabase::addDatabase("QSQLITE");
    m_db.setDatabaseName("users.db");

    if (!m_db.open()) {
        qDebug() << "[DB ERROR]" << m_db.lastError().text();
        return false;
    }

    QSqlQuery query;
    // Новая таблица с счётчиками задач 1-4
    query.exec("CREATE TABLE IF NOT EXISTS users ("
               "id INTEGER PRIMARY KEY AUTOINCREMENT, "
               "username TEXT UNIQUE, "
               "password TEXT, "
               "role TEXT, "
               "task1_count INTEGER DEFAULT 0, "
               "task2_count INTEGER DEFAULT 0, "
               "task3_count INTEGER DEFAULT 0, "
               "task4_count INTEGER DEFAULT 0)");

    // Admin user
    query.prepare("SELECT COUNT(*) FROM users WHERE username = 'admin'");
    query.exec();
    if (query.next() && query.value(0).toInt() == 0) {
        query.prepare("INSERT INTO users (username, password, role, task1_count, task2_count, task3_count, task4_count) VALUES (?, ?, ?, 0, 0, 0, 0)");
        query.addBindValue("admin");
        query.addBindValue(hashPassword("admin123"));
        query.addBindValue("admin");
        query.exec();
        qDebug() << "[DB] Admin created: admin/admin123";
    }

    // Regular user
    query.prepare("SELECT COUNT(*) FROM users WHERE username = 'user1'");
    query.exec();
    if (query.next() && query.value(0).toInt() == 0) {
        query.prepare("INSERT INTO users (username, password, role, task1_count, task2_count, task3_count, task4_count) VALUES (?, ?, ?, 0, 0, 0, 0)");
        query.addBindValue("user1");
        query.addBindValue(hashPassword("pass123"));
        query.addBindValue("user");
        query.exec();
        qDebug() << "[DB] User created: user1/pass123";
    }

    return true;
}

bool Database::validateUser(const QString &username, const QString &password)
{
    QSqlQuery query;
    query.prepare("SELECT password FROM users WHERE username = ?");
    query.addBindValue(username);

    if (query.exec() && query.next()) {
        return query.value(0).toString() == hashPassword(password);
    }
    return false;
}

bool Database::registerUser(const QString &username, const QString &password)
{
    QSqlQuery query;
    query.prepare("SELECT COUNT(*) FROM users WHERE username = ?");
    query.addBindValue(username);
    query.exec();

    if (query.next() && query.value(0).toInt() > 0) {
        return false;
    }

    query.prepare("INSERT INTO users (username, password, role, task1_count, task2_count, task3_count, task4_count) VALUES (?, ?, 'user', 0, 0, 0, 0)");
    query.addBindValue(username);
    query.addBindValue(hashPassword(password));

    return query.exec();
}

QString Database::getUserRole(const QString &username)
{
    QSqlQuery query;
    query.prepare("SELECT role FROM users WHERE username = ?");
    query.addBindValue(username);

    if (query.exec() && query.next()) {
        return query.value(0).toString();
    }
    return "user";
}

void Database::incrementTaskCount(const QString &username, int taskNumber)
{
    QString columnName;
    switch (taskNumber) {
        case 1: columnName = "task1_count"; break;
        case 2: columnName = "task2_count"; break;
        case 3: columnName = "task3_count"; break;
        case 4: columnName = "task4_count"; break;
        default: return;
    }
    
    QSqlQuery query;
    query.prepare(QString("UPDATE users SET %1 = %1 + 1 WHERE username = ?").arg(columnName));
    query.addBindValue(username);
    query.exec();
}

QVector<QJsonObject> Database::getAllUsers()
{
    QVector<QJsonObject> users;
    // Выбираем ТОЛЬКО пользователей с ролью 'user' (админа не показываем)
    QSqlQuery query("SELECT id, username, role, task1_count, task2_count, task3_count, task4_count FROM users WHERE role = 'user'");

    while (query.next()) {
        QJsonObject user;
        user["id"] = query.value(0).toInt();
        user["username"] = query.value(1).toString();
        user["role"] = query.value(2).toString();
        user["task1_count"] = query.value(3).toInt();
        user["task2_count"] = query.value(4).toInt();
        user["task3_count"] = query.value(5).toInt();
        user["task4_count"] = query.value(6).toInt();
        user["total"] = user["task1_count"].toInt() + 
                        user["task2_count"].toInt() + 
                        user["task3_count"].toInt() + 
                        user["task4_count"].toInt();
        users.append(user);
    }
    return users;
}

QString Database::hashPassword(const QString &password)
{
    return QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Sha256).toHex();
}

Database& Database::instance()
{
    static Database instance;
    return instance;
}